exports.log = function log(message) {
    console.log('[INFO] ' + message);
  }